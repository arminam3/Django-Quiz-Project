function createForm() {
    const formContainer = document.getElementById('formContainer-cus');
    const form = document.createElement('form');
    
    // Add form elements (e.g., input fields, labels) dynamically here
    form.innerHTML = `
    <div class="col-xl-12 col-lg-12">
    <div class="card">
        <div class="card-header">
            <h4 class="card-title">ایجاد سوال</h4>
        </div>
        <div class="card-body">
            <div class="basic-form">
                <form  action="{% url 'question_create' %}" enctype="multipart/form-data" method="POST">
                    {% csrf_token %}
                    <div class="mb-1 row">
                        <label class="col-sm-2 col-form-label text-primary" style="font-size: medium;">
                            <b>متن سوال</b>
                        </label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" placeholder="متن سوال را اضافه کنید" required name="text">
                        </div>
                    </div>
                    <div class="mb-1 row">
                        <label class="col-sm-2 col-form-label">گزینه اول </label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="choice_1" required>
                        </div>
                    </div>
                    <div class="mb-1 row">
                        <label class="col-sm-2 col-form-label">گزینه دوم</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="choice_2" required>
                        </div>
                    </div>
                    <div class="mb-1 row">
                        <label class="col-sm-2 col-form-label">گزینه سوم</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="choice_3" required>
                        </div>
                    </div>
                    <div class="mb-1 row">
                        <label class="col-sm-2 col-form-label">گزینه چهارم</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" name="choice_4" required>
                        </div>
                    </div>

                    <fieldset class="mb-3">
                        <div class="row">
                            <label class="col-form-label col-sm-2 pt-0">پاسخ</label>
                            <div class="col-sm-10">
                                <div class="col-sm-3">
                                    <div class="form-check">
                                        <input class="form-check-input rtl-choice-cus" type="radio" name="answer" value="1"  required>
                                        <label class="form-check-label">
                                            {{1|e2fnum}}
                                        </label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check">
                                        <input class="form-check-input rtl-choice-cus" type="radio" name="answer" value="2"  required>
                                        <label class="form-check-label">
                                            {{2|e2fnum}}
                                        </label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check">
                                        <input class="form-check-input rtl-choice-cus" type="radio" name="answer" value="3"  required>
                                        <label class="form-check-label">
                                            {{3|e2fnum}}
                                        </label>
                                    </div>
                                </div>
                                <div class="col-sm-3">
                                    <div class="form-check">
                                        <input class="form-check-input rtl-choice-cus" type="radio" name="answer" value="4"  required>
                                        <label class="form-check-label">
                                            {{4|e2fnum}}
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <label class="col-form-label col-sm-3 pt-0 farsi">تصویر</label>
                            <div class="col-sm-9">
                                <div class="input-group custom_file_input">
                                    <div class="form-file">
                                        <input type="file" class="form-file-input form-control" name="image">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </fieldset>
                    <!-- <div class="mb-3 row">
                        <div class="col-sm-3">Checkbox</div>
                        <div class="col-sm-9">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox">
                                <label class="form-check-label">
                                    Example checkbox
                                </label>
                            </div>
                        </div>
                    </div> -->
                    <div class="mb-3 row">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary ">ثبت سوال</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
    `;
    
    formContainer.appendChild(form);
  }