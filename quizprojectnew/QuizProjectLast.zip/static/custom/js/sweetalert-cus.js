"use strict";

document.querySelector(".sweet-confirm").onclick = function() {
    swal({
        title: "Are you sure to delete?",
        text: "You will not be able to recover this imaginary file!!",
        type: "warning",
        showCancelButton: true,
        confirmButtonColor: "#DD6B55",
        confirmButtonText: "Yes, delete it!!",
        closeOnConfirm: false
    }, function(isConfirmed) {
        if (isConfirmed) {
            // Proceed with form submission here
            swal("Deleted!!", "Hey, your imaginary file has been deleted!!", "success");
        } else {
            // Handle cancellation or do nothing
        }
    });
};